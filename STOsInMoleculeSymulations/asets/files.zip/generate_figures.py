"""
Generate figures for the STO amplitude encoding paper.
Publication-quality matplotlib figures suitable for PRA/Quantum.
"""

import matplotlib.pyplot as plt
import matplotlib
import numpy as np

matplotlib.rcParams.update({
    'font.family': 'serif',
    'font.size': 11,
    'axes.labelsize': 12,
    'axes.titlesize': 13,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 9,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'text.usetex': False,
})

# ============================================================
# Data extracted from experiment files
# ============================================================

# Overlap data (statevector = analytical sim, exact = continuous integral)
overlap_data = {
    # n: (exact_continuous, statevector, ecr_gates, discretized_distance)
    4:  (0.735759, 0.800212, 58, 1.0),
    5:  (0.557825, 0.571947, 105, 1.5),
    6:  (0.557825, 0.561323, 148, 1.5),
    7:  (0.600494, 0.601400, 230, 1.375),
    8:  (0.600494, 0.600721, 236, 1.375),
    9:  (0.589677, 0.589733, 330, 1.40625),
    10: (0.589677, 0.589691, 364, 1.40625),
}

# Kinetic data
kinetic_data = {
    4:  (0.000000, -0.032227, 62),
    5:  (-0.055783, -0.062844, 110),
    6:  (-0.055783, -0.057532, 132),
    7:  (-0.047407, -0.047861, 211),
    8:  (-0.047407, -0.047521, 238),
    9:  (-0.049778, -0.049807, 333),
    10: (-0.049778, -0.049785, 368),
}

# Hardware results (ibm_kingston, best runs)
hw_overlap = {
    5: {'exact': 0.557825, 'sv': 0.571947, 'hw_sampler': 0.494347, 
        'hw_zne': 0.575771, 'cz': 104},
    6: {'exact': 0.557825, 'sv': 0.561323, 'hw_sampler': 0.373149, 
        'hw_zne': 0.450336, 'cz': 134},
    8: {'exact': 0.600494, 'sv': 0.600721, 'hw_sampler': 0.333822, 
        'hw_zne': 0.308880, 'cz': 238},
}

hw_kinetic = {
    5: {'exact': -0.055783, 'sv': -0.062844, 'hw_sampler': -0.046761,
        'hw_zne': -0.056810, 'cz': 107},
}

# Bond dimension data (from earlier analysis)
# n: max_chi for psi, V*psi, cartesian_3d
bond_dim_data = {
    4:  (3, 4, 16),
    5:  (3, 4, 32),
    6:  (3, 8, 64),
    7:  (3, 8, 128),
    8:  (3, 11, 256),
    9:  (3, 12, 512),
    10: (3, 12, 1024),
    11: (3, 12, 2048),
    12: (3, 12, 4096),
    13: (3, 12, 8192),
    14: (3, 12, 16384),
}

# ============================================================
# Figure 1: Discretization convergence
# ============================================================

fig1, (ax1a, ax1b) = plt.subplots(1, 2, figsize=(10, 4))

ns = sorted(overlap_data.keys())
disc_err_overlap = [abs(overlap_data[n][1] - overlap_data[n][0]) / abs(overlap_data[n][0]) * 100 
                     for n in ns]
disc_err_kinetic = []
for n in ns:
    ex, sv, _ = kinetic_data[n]
    if abs(ex) > 1e-10:
        disc_err_kinetic.append(abs(sv - ex) / abs(ex) * 100)
    else:
        disc_err_kinetic.append(None)

# Panel a: absolute values
ax1a.plot(ns, [overlap_data[n][0] for n in ns], 'k--', label='Exact (continuous)', linewidth=1.5)
ax1a.plot(ns, [overlap_data[n][1] for n in ns], 'o-', color='#2166ac', 
          label='Statevector (discretized)', markersize=6, linewidth=1.5)
ax1a.set_xlabel('Number of qubits (n)')
ax1a.set_ylabel('Overlap integral S$_{AB}$')
ax1a.set_title('(a) Overlap: simulation vs. exact')
ax1a.legend(frameon=True, fancybox=False, edgecolor='gray')
ax1a.set_xticks(ns)
ax1a.grid(True, alpha=0.3)

# Panel b: discretization error (%)
valid_ns_k = [n for n in ns if disc_err_kinetic[ns.index(n)] is not None]
valid_errs_k = [e for e in disc_err_kinetic if e is not None]

ax1b.semilogy(ns, disc_err_overlap, 's-', color='#2166ac', label='Overlap S$_{AB}$', 
              markersize=6, linewidth=1.5)
ax1b.semilogy(valid_ns_k, valid_errs_k, 'D-', color='#b2182b', label='Kinetic T$_{AB}$', 
              markersize=6, linewidth=1.5)
ax1b.set_xlabel('Number of qubits (n)')
ax1b.set_ylabel('Discretization error (%)')
ax1b.set_title('(b) Discretization error vs. qubit count')
ax1b.legend(frameon=True, fancybox=False, edgecolor='gray')
ax1b.set_xticks(ns)
ax1b.grid(True, alpha=0.3)

fig1.tight_layout()
fig1.savefig('/home/claude/fig1_convergence.pdf')
fig1.savefig('/home/claude/fig1_convergence.png')
print("Figure 1 saved.")


# ============================================================
# Figure 2: Hardware comparison (5-qubit Kingston)
# ============================================================

fig2, (ax2a, ax2b) = plt.subplots(1, 2, figsize=(10, 4.5))

# Overlap comparison
categories = ['Exact\n(continuous)', 'Statevector\n(discretized)', 'Noiseless\nsampler', 
              'Hardware\nsampler', 'Hardware\nZNE']
overlap_vals = [0.557825, 0.571947, 0.571115, 0.494347, 0.575771]  # Kingston 5q best
colors_ov = ['#333333', '#2166ac', '#4393c3', '#d6604d', '#b2182b']

bars = ax2a.bar(categories, overlap_vals, color=colors_ov, edgecolor='white', linewidth=0.5)
ax2a.axhline(y=0.557825, color='gray', linestyle='--', alpha=0.5, linewidth=1)
ax2a.set_ylabel('Overlap integral S$_{AB}$')
ax2a.set_title('(a) Overlap (5 qubits, ibm_kingston)')
ax2a.set_ylim(0.35, 0.65)
# Add value labels
for bar, val in zip(bars, overlap_vals):
    ax2a.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.005, 
              f'{val:.3f}', ha='center', va='bottom', fontsize=9)

# Kinetic comparison
kinetic_vals = [-0.055783, -0.062844, -0.063170, -0.046761, -0.056810]  # Kingston 5q best
colors_k = ['#333333', '#2166ac', '#4393c3', '#d6604d', '#b2182b']

bars_k = ax2b.bar(categories, [abs(v) for v in kinetic_vals], color=colors_k, 
                   edgecolor='white', linewidth=0.5)
ax2b.axhline(y=abs(-0.055783), color='gray', linestyle='--', alpha=0.5, linewidth=1)
ax2b.set_ylabel('|Kinetic integral T$_{AB}$|')
ax2b.set_title('(b) Kinetic energy (5 qubits, ibm_kingston)')
ax2b.set_ylim(0.0, 0.09)
for bar, val in zip(bars_k, kinetic_vals):
    ax2b.text(bar.get_x() + bar.get_width()/2, abs(val) + 0.001, 
              f'{abs(val):.4f}', ha='center', va='bottom', fontsize=8)

fig2.tight_layout()
fig2.savefig('/home/claude/fig2_hardware.pdf')
fig2.savefig('/home/claude/fig2_hardware.png')
print("Figure 2 saved.")


# ============================================================
# Figure 3: Bond dimension analysis (three panels)
# ============================================================

fig3, (ax3a, ax3b, ax3c) = plt.subplots(1, 3, figsize=(12, 4))

ns_bd = sorted(bond_dim_data.keys())

# Panel a: orbital chi = 3
ax3a.plot(ns_bd, [bond_dim_data[n][0] for n in ns_bd], 'o-', color='#2166ac',
          markersize=6, linewidth=1.5)
ax3a.set_xlabel('Number of qubits (n)')
ax3a.set_ylabel('Max bond dimension χ')
ax3a.set_title('(a) ψ(x) = e$^{-ζ|x-R|}$')
ax3a.set_ylim(0, 8)
ax3a.set_xticks(ns_bd)
ax3a.grid(True, alpha=0.3)
ax3a.annotate('χ = 3 (constant)', xy=(8, 3), fontsize=10, color='#2166ac',
              ha='center', va='bottom')

# Panel b: V*psi saturates at 12
ax3b.plot(ns_bd, [bond_dim_data[n][1] for n in ns_bd], 's-', color='#b2182b',
          markersize=6, linewidth=1.5)
ax3b.axhline(y=12, color='gray', linestyle='--', alpha=0.5)
ax3b.set_xlabel('Number of qubits (n)')
ax3b.set_ylabel('Max bond dimension χ')
ax3b.set_title('(b) V(x)·ψ(x) = e$^{-ζ|x-R|}$/|x−R$_C$|')
ax3b.set_ylim(0, 20)
ax3b.set_xticks(ns_bd)
ax3b.grid(True, alpha=0.3)
ax3b.annotate('χ → 12 (saturates)', xy=(10, 13), fontsize=10, color='#b2182b',
              ha='center')

# Panel c: Cartesian 3D exponential
ax3c.semilogy(ns_bd, [bond_dim_data[n][2] for n in ns_bd], 'D-', color='#1b7837',
              markersize=6, linewidth=1.5)
ax3c.semilogy(ns_bd, [2**n for n in ns_bd], 'k--', alpha=0.4, linewidth=1, label='2$^n$')
ax3c.set_xlabel('Number of qubits (n)')
ax3c.set_ylabel('Max bond dimension χ')
ax3c.set_title('(c) e$^{-ζ\\sqrt{x^2+y^2+z^2}}$ (Cartesian)')
ax3c.set_xticks(ns_bd)
ax3c.legend(frameon=True, fancybox=False, edgecolor='gray')
ax3c.grid(True, alpha=0.3)

fig3.tight_layout()
fig3.savefig('/home/claude/fig3_bond_dimension.pdf')
fig3.savefig('/home/claude/fig3_bond_dimension.png')
print("Figure 3 saved.")


# ============================================================
# Figure 4: Error vs CZ gate count
# ============================================================

fig4, ax4 = plt.subplots(figsize=(7, 4.5))

# Collect all hardware overlap data points (noisy simulation = fake_sherbrooke)
# Using noisy estimation (ZNE) from fake_sherbrooke for all qubit counts
noisy_zne_overlap = {
    4: (58, abs(0.575764 - 0.800212) / 0.800212),   # vs statevector
    5: (105, abs(0.430065 - 0.571947) / 0.571947),
    6: (148, abs(0.363707 - 0.561323) / 0.561323),
    7: (230, abs(0.257179 - 0.601400) / 0.601400),
    8: (236, abs(0.280021 - 0.600721) / 0.600721),
    9: (330, abs(0.211948 - 0.589733) / 0.589733),
    10: (364, abs(0.098821 - 0.589691) / 0.589691),
}

# Real hardware (Kingston)
real_hw = {
    5: (104, abs(0.575771 - 0.571947) / 0.571947),  # ZNE
    6: (134, abs(0.450336 - 0.561323) / 0.561323),
    8: (238, abs(0.308880 - 0.600721) / 0.600721),
}

cz_noisy = [noisy_zne_overlap[n][0] for n in sorted(noisy_zne_overlap.keys())]
err_noisy = [noisy_zne_overlap[n][1] * 100 for n in sorted(noisy_zne_overlap.keys())]

cz_real = [real_hw[n][0] for n in sorted(real_hw.keys())]
err_real = [real_hw[n][1] * 100 for n in sorted(real_hw.keys())]

ax4.semilogy(cz_noisy, err_noisy, 's-', color='#4393c3', label='Noisy sim (ZNE)', 
             markersize=7, linewidth=1.5)
ax4.semilogy(cz_real, err_real, 'D-', color='#b2182b', label='IBM Kingston (ZNE)', 
             markersize=8, linewidth=1.5)

# Theoretical survival probability curve
cz_range = np.linspace(50, 400, 100)
eps = 0.005  # approximate CZ error rate
survival = (1 - (1 - eps)**cz_range) * 100
ax4.semilogy(cz_range, survival, 'k--', alpha=0.4, linewidth=1, 
             label=f'1 − (1−ε)$^{{N_{{CZ}}}}$, ε={eps}')

ax4.set_xlabel('Number of CZ/ECR gates')
ax4.set_ylabel('Hardware noise (% of statevector)')
ax4.set_title('Hardware error scaling with circuit size')
ax4.legend(frameon=True, fancybox=False, edgecolor='gray')
ax4.grid(True, alpha=0.3)
ax4.set_ylim(0.1, 100)

# Annotate qubit counts
for n in sorted(real_hw.keys()):
    cz, err = real_hw[n]
    ax4.annotate(f'{n}q', xy=(cz, err*100), xytext=(5, 5), 
                 textcoords='offset points', fontsize=9, color='#b2182b')

fig4.tight_layout()
fig4.savefig('/home/claude/fig4_error_scaling.pdf')
fig4.savefig('/home/claude/fig4_error_scaling.png')
print("Figure 4 saved.")


# ============================================================
# Table: Summary of key results (printed to console)
# ============================================================

print("\n" + "="*80)
print("TABLE: Summary of integral results")
print("="*80)
print(f"{'Integral':<20} {'n':>3} {'Exact':>10} {'Statevec':>10} {'HW ZNE':>10} "
      f"{'Disc err%':>10} {'HW err%':>10}")
print("-"*80)

# Overlap
for n in [5, 6, 8]:
    ex = hw_overlap[n]['exact']
    sv = hw_overlap[n]['sv']
    zne = hw_overlap[n]['hw_zne']
    disc = abs(sv - ex) / abs(ex) * 100
    hw_e = abs(zne - sv) / abs(sv) * 100
    print(f"{'Overlap S_AB':<20} {n:>3} {ex:>10.4f} {sv:>10.4f} {zne:>10.4f} "
          f"{disc:>9.2f}% {hw_e:>9.2f}%")

# Kinetic (5q Kingston)
print(f"{'Kinetic T_AB':<20} {5:>3} {-0.055783:>10.4f} {-0.062844:>10.4f} "
      f"{-0.056810:>10.4f} {12.66:>9.2f}% {9.60:>9.2f}%")

print()
print("Circuit metrics:")
print(f"{'Circuit':<25} {'n':>3} {'CZ gates':>10} {'Depth':>8}")
print("-"*50)
print(f"{'Overlap (Kingston)':<25} {5:>3} {104:>10} {266:>8}")
print(f"{'Overlap (Kingston)':<25} {8:>3} {238:>10} {553:>8}")
print(f"{'Kinetic (Kingston)':<25} {5:>3} {107:>10} {264:>8}")
print(f"{'Orthogonality (Marr.)':<25} {5:>3} {186:>10} {679:>8}")
print(f"{'Nuc. attraction (sim)':<25} {6:>3} {'8486':>10} {'36624':>8}")

print("\nAll figures saved to /home/claude/")
